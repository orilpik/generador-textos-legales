=== Generador de textos legales ===
Contributors: orilpik
Tags: aviso legal, política de privacidad, política de cookies, legal, generador de textos legales
Requires at least: 5.0
Tested up to: 5.9
Requires PHP: 7.2
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Aquí una breve descripción de lo que hace el plugin.

== Description ==

El plugin crea tres páginas: Aviso Legal, Política de privacidad y Política de cookies (si ya existen es necesario borrarlas para que funcione correctamente, ya que comprueba que existan) en base a los datos empresariales que se le introduzcan.

== Installation ==

Sólo se requiere activarlo y rellenar con tus datos empresariales. Tras hacer clic en generar, ya puedes borrar el plugin.

== Frequently Asked Questions ==

= ¿Para qué sirve? =

Te crea las páginas estándar de Aviso Legal y Política de privacidad para cubrir el expediente.


== Changelog ==

= 1.1 =
* Corrección de errores menores

= 1.0 =
* Lanzamiento inicial del plugin.

== Upgrade Notice ==

= 1.0 =
Lanzamiento inicial.
